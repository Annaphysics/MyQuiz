package com.anna.myquiz;
/** This class manages the Student object*/
public class Student {
    private  String studentAm;
    private String studentName;
    private  String studentSemester;
    private static int studentScore;
    private String studentDate;
    private int id;
    private static long elapsedTime;

    /** The constructor creates an object with the information provided*/
    public Student(){}

    public Student (String studentAm, String studentName, String studentSemester, int studentScore, String studentDate, int id, long elapsedTime) {
        this.studentAm = studentAm;
        this.studentName = studentName;
        this.studentSemester = studentSemester;
        this.studentScore = studentScore;
        this.studentDate = studentDate;
        this.id = id;
        this.elapsedTime = elapsedTime ;
    }

    /** Getters and Setters*/
    public String getStudentAm () {
        return studentAm;
    }

    public void setStudentAm (String studentAm) {
        this.studentAm = studentAm;
    }

    public String getStudentName () {
        return studentName;
    }

    public void setStudentName (String studentName) {
        this.studentName = studentName;
    }

    public String getStudentSemester () {
        return studentSemester;
    }

    public void setStudentSemester (String studentSemester) {this.studentSemester = studentSemester; }

    public static int getStudentScore () {
        return studentScore;
    }

    public void setStudentScore (int studentScore) {
        this.studentScore = studentScore;
    }

    public String getStudentDate () { return studentDate; }

    public void setStudentDate (String studentDate) { this.studentDate = studentDate; }

    public int getId () {
        return id;
    }

    public void setId (int id) {
        this.id = id;
    }

    public static long getElapsedTime () {
        return elapsedTime;
    }

    public static void setElapsedTime (long elapsedTime) {
        Student.elapsedTime = elapsedTime;
    }
}
