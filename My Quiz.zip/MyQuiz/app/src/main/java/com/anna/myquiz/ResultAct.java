package com.anna.myquiz;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.view.View;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

/** This class displays the test results on the user screen */
public class ResultAct extends AppCompatActivity {
    private TextView tViewNameRes;
    private TextView tViewAmRes;
    private TextView tViewSemesterRes;
    private TextView tVdate;
    private Button butResults;
    private TextView tVHighScore;
    private DataDbHelper StudentDb;
    private ArrayList<Student> studentList;
    private Student currentStudent;
    private Button buttonExit;
    private TextView tVelapsedTime;
    private ImageView TVImageResult;

    /** This class  Called when the activity is first created.
     * Sets the quiz layout from the activity_result.xml file.
     *  Activates the Result and Exit buttons.
     *  Creates a database object.  */

    @Override
    protected void onCreate (Bundle savedInstanceState) {

        super.onCreate (savedInstanceState);
        DataDbHelper dbHelper = new DataDbHelper (this);
        setContentView (R.layout.activity_result);
        tViewNameRes = findViewById (R.id.tViewNameRes);
        tViewAmRes = findViewById (R.id.tViewAmRes);
        tViewSemesterRes = findViewById (R.id.tViewSemesterRes);
        tVHighScore = findViewById (R.id.tVHighScore);
        tVdate = findViewById (R.id.tVdate);
        tVelapsedTime = findViewById (R.id.tVelapsedTime);
        StudentDb = new DataDbHelper (ResultAct.this);
        studentList = (ArrayList<Student>) dbHelper.getAllStudent ();
        butResults = findViewById (R.id.butResults);
        buttonExit = findViewById (R.id.buttonExit);
        TVImageResult = findViewById (R.id.TVImageResult);

        butResults.setOnClickListener (new View.OnClickListener () {
            /** This method sets text views visible and calls the methods in order to to display the results on the screen  . */
            @Override
            public void onClick (View v) {

                tViewNameRes.setVisibility(View.VISIBLE);
                tViewAmRes.setVisibility(View.VISIBLE);
                tViewSemesterRes.setVisibility(View.VISIBLE);
                tVHighScore.setVisibility(View.VISIBLE);
                tVdate.setVisibility(View.VISIBLE);
                tVelapsedTime.setVisibility(View.VISIBLE);
                TVImageResult.setVisibility(View.INVISIBLE);
                playSound();
                loadGrade();
                loadStudentInfo();
                loadTimeInfo();

            }
        });
        buttonExit.setOnClickListener (new View.OnClickListener () {
            /**This method is called when button exit is pushed and Jumps to IntroAct activity */
            @Override
            public void onClick (View v) {
                Intent intent = new Intent (getApplicationContext (), IntroAct.class);
                startActivity (intent);
                finish ();
            }
        });
    }
    /** This method displays the student's details on the screen. */
    private void  loadStudentInfo(){

        currentStudent= studentList.get(studentList.size ()-1);
        tViewAmRes.setText ("Student ID:" + currentStudent.getStudentAm ());
        tViewNameRes.setText ("Student Name:" + currentStudent.getStudentName ());
        tViewSemesterRes.setText ("Semester:" + currentStudent.getStudentSemester ());
    }

    /** This method plays intro melody on button Result click */
    private void playSound() {
        MediaPlayer mediaPlayer;
        MediaPlayer music = MediaPlayer.create (ResultAct.this, R.raw.goodmorning);
        music.start ();
    }

    /** This method displays the current time and elapsed time  on the screen. */
    private void  loadTimeInfo(){
        Calendar c = Calendar.getInstance();
        System.out.println("Current time => "+c.getTime());
        SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy - HH:mm:ss");
        String formattedDate = df.format(c.getTime());

        tVdate.setText ("Date - Time: "+formattedDate);
        DataDbHelper.storeDate(formattedDate);
        long duration_time = getIntent().getLongExtra (QuestionsAct.QUIZ_TIME, 0);
        tVelapsedTime.setText ("Elapsed Time :" + duration_time+ "sec");
    }

    /** This method displays the student's grade on the screen. */
    private void loadGrade() {

        int finalScore = getIntent().getIntExtra(QuestionsAct.EXTRA_GRADE, 0);

        tVHighScore.setText("Grade: " + finalScore);
    }

}