package com.anna.myquiz;
import android.provider.BaseColumns;

/**  This Class is creating  constant variables for the two tables of our database.  */
public final class DataContract {
    private  DataContract(){}
    /**  This Class is creating  constant variables for the  tables that contains student details.  */
    public static class StudentTable implements BaseColumns {

        public static final String TABLE_NAME1 = "student_info";
        public static final String COLUMN_ID = "id";
        public static final String COLUMN_AM = "studentAm";
        public static final String COLUMN_NAME = "name";
        public static final String COLUMN_SEMESTER = "semester";
        public static final String COLUMN_GRADE = "studentGrade";
        public static final String COLUMN_DATE = "studentDate";
        public static final String COLUMN_ELAPSEDTIME = "elapsedTime";
    }
    /**  This Class is creating  constant variables for the  tables that contains quiz details.  */
    public static class QuestionTable implements BaseColumns {
        public static final String TABLE_NAME = "quiz_question";
        public static final String COLUMN_QUESTION = "question";
        public static final String COLUMN_IMAGE = "image";
        public static final String COLUMN_ANSWER1 = "answer1";
        public static final String COLUMN_ANSWER2 = "answer2";
        public static final String COLUMN_ANSWER3 = "answer3";
        public static final String COLUMN_ANSWER4 = "answer4";
        public static final String COLUMN_ANSWERNUM = "answerNum";

    }
}
