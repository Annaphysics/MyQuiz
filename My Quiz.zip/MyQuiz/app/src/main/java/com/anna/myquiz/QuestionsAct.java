package com.anna.myquiz;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.media.MediaPlayer;
import android.os.CountDownTimer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Collections;
import android.graphics.Color;
import java.util.Locale;

/** The class manages the activity for the questions of the quiz.*/
public class QuestionsAct extends AppCompatActivity {

    private TextView tvQuestion;
    private TextView tvQuestionCount;
    private TextView tvTime;
    private RadioGroup radioGroup;
    private RadioButton radioButton1;
    private RadioButton radioButton2;
    private RadioButton radioButton3;
    private RadioButton radioButton4;
    private Button butConfirmAns;
    private ImageView tvImgQuest;

    private ColorStateList textColorDefaultRb;
    private ColorStateList textColorDefaultCd;

    private ArrayList<Question> questionList;
    private int questionCounter;
    private int questionCountTotal;
    private Question currentQuestion;

    private int score;     /** Counter for correct questions */
    private boolean answered;

    //-----------score variables---------------
    public static final String EXTRA_GRADE = "extraScore";
    //--------------time variables---------------------------
    //private static final long COUNTDOWN_TIME = 3600000;
    private static final long COUNTDOWN_TIME = 30000;
    public static final String QUIZ_TIME = "QuizElapsed";
    private CountDownTimer countDownTimer;
    private long timeLeft;
    public static final int numberOfQuestions = 3;

    /** Called when the activity is first created.
     *  Sets the quiz layout from the .xml file.
     *  Activate the event for the answers buttons*/
    @Override
    protected void onCreate (Bundle savedInstanceState)
    {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_questions);

        tvQuestion = findViewById (R.id.tVQuestion);
        tvQuestionCount = findViewById (R.id.tvQuestionCount);
        tvTime = findViewById (R.id.tVTime);

        radioGroup = findViewById (R.id.radioGroup);
        radioButton1 = findViewById (R.id.radioButton1);
        radioButton2 = findViewById (R.id.radioButton2);
        radioButton3 = findViewById (R.id.radioButton3);
        radioButton4 = findViewById (R.id.radioButton4);
        butConfirmAns =  findViewById (R.id.butConfirmAns);
        tvImgQuest = findViewById (R.id.tvImgQuest);
        textColorDefaultRb = radioButton1.getTextColors ();
        textColorDefaultCd = tvTime.getTextColors();
        DataDbHelper dbHelper = new DataDbHelper (this);
        questionList =  dbHelper.getAllQuestions ();
        questionCountTotal = questionList.size ();
        Collections.shuffle (questionList);
        timeLeft = COUNTDOWN_TIME;

        startCountDown();
        showNextQuestion ();
/** Clears the selection. When the selection is cleared, no radio button in this group is selected and getCheckedRadioButtonId() returns null. */
        radioGroup.clearCheck();

        butConfirmAns.setOnClickListener (new View.OnClickListener ()
        {
            @Override
            public void onClick(View v)
            {
                if(!answered)
                {
                    if (radioButton1.isChecked() || radioButton2.isChecked() || radioButton3.isChecked() || radioButton4.isChecked())
                    {
                        checkAnswer();
                    }
                    else {
                        Toast.makeText (QuestionsAct.this, "Please select an answer", Toast.LENGTH_SHORT).show ();
                    }
                }
                else {
                    showNextQuestion ();
                }
            }
        });
    }

    /** Called after a question is answered to refresh the screen with the question and new answers.     */
    @SuppressLint("SetTextI18n")
    private void showNextQuestion()
    {
        radioButton1.setTextColor (textColorDefaultRb);
        radioButton2.setTextColor (textColorDefaultRb);
        radioButton3.setTextColor (textColorDefaultRb);
        radioButton4.setTextColor (textColorDefaultRb);
        radioGroup.clearCheck();

         if (questionCounter < questionCountTotal )
         {
             currentQuestion = questionList.get(questionCounter);
            /**Hide image view  in case there is no image in question */
              tvQuestion.setText(currentQuestion.getQuestion ());

                if(currentQuestion.getImage() == null || currentQuestion.getImage().isEmpty())
                {
                   tvImgQuest.setVisibility (View.INVISIBLE);
                }
                else
                    {
                       ImageView tvImgQuest = findViewById(R.id.tvImgQuest);
                        tvImgQuest.setVisibility (View.VISIBLE);

             /**  Get an image name from table quiz_question */
                         Context context =tvImgQuest.getContext();
                         int id = context.getResources().getIdentifier(currentQuestion.getImage(), "drawable", context .getPackageName());
                          tvImgQuest.setImageResource(id);

                     }
             radioButton1.setText(currentQuestion.getAnswer1 ());
             radioButton2.setText(currentQuestion.getAnswer2 ());
             radioButton3.setText(currentQuestion.getAnswer3 ());

            /**Hide radio button in case the possible answers are three */
            if(currentQuestion.getAnswer4() == null || currentQuestion.getAnswer4().isEmpty())
              {
                   radioButton4.setVisibility(View.INVISIBLE);
              }
            else
                    {
                        radioButton4.setVisibility(View.VISIBLE);
                        radioButton4.setText(currentQuestion.getAnswer4());
                    }

            questionCounter++;
            tvQuestionCount.setText("Question: " + questionCounter + "/" + questionCountTotal);
            answered = false;
            butConfirmAns.setText("Submit");
        }
        else
            {
            finishQuiz();
            }

    }
/** This method determines if the answer is correct  and increases the value of variable score   */
    @SuppressLint("SetTextI18n")

    private void checkAnswer()
    {
        answered = true;

        RadioButton rbSelected = findViewById(radioGroup.getCheckedRadioButtonId());
        int answerNum = radioGroup.indexOfChild(rbSelected) + 1;

        if (answerNum == currentQuestion.getAnswerNum()){
            score++;

        }

        checkEndOfQuiz();
    }
    /** This method :
     * checks if there is any question left and modifies the button text froM SUBMIT to  NEXT or FINISH
     * on FINISH counts elapsed time
     * call method addScore  in order to set the values of grade and elapsed time in student table*/
    @SuppressLint("SetTextI18n")
    private void checkEndOfQuiz()
    {
        if (questionCounter < questionCountTotal)
        {
            butConfirmAns.setText("Next");
        }
        else {
            long  elapsed_time = (COUNTDOWN_TIME - timeLeft)/1000;
            butConfirmAns.setText("Finish");
            playSoundComplete();
            int finalScore = score*100/numberOfQuestions;
            DataDbHelper.addScore(finalScore,elapsed_time);
            countDownTimer.cancel();
        }
    }
    /**This method is called when the quiz is finished and Jumps to ResultAct activity */
    private void finishQuiz()
    {
        Intent  ResultAct = new Intent(QuestionsAct.this,ResultAct.class);
        int finalScore = score*100/numberOfQuestions;
        long  elapsed_time = (COUNTDOWN_TIME - timeLeft)/1000;
        ResultAct.putExtra (EXTRA_GRADE , finalScore);
        ResultAct.putExtra (QUIZ_TIME, elapsed_time);
        startActivity (ResultAct);
    }

    private void playSound() {

        MediaPlayer music = MediaPlayer.create(QuestionsAct.this, R.raw.voicetone);
        music.start();
    }

    private void playSoundComplete() {

        MediaPlayer music = MediaPlayer.create (QuestionsAct.this, R.raw.completedringtone);
        music.start ();
    }

    /**This method creates the  Countdown Clock */

    private void startCountDown()
    {
        countDownTimer = new CountDownTimer(timeLeft, 1000)
        {
            @Override
            public void onTick(long timeUntilFinished)
            {
                timeLeft = timeUntilFinished;
                updateCountDownText();
            }

            @Override
            public void onFinish()
            {
                timeLeft = 0;
                updateCountDownText();

            }
        }.start ();
    }

    /**This method formates  the text of  Countdown Clock  and checks  the end of time*/
    private void updateCountDownText() {
        int minutes = (int) (timeLeft / 1000) / 60;
        int seconds = (int) (timeLeft / 1000) % 60;

        String timeFormatted = String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds);

        tvTime.setText(timeFormatted);

        if (timeLeft < 10000) {
            tvTime.setTextColor(Color.RED);

        } else {
            tvTime.setTextColor(textColorDefaultCd);
        }
        if (timeLeft == 0) {
           playSound();
            finishQuiz();

        }
    }

    @Override

    protected void onDestroy() {
        super.onDestroy();
        if (countDownTimer != null) {
            countDownTimer.cancel();

        }
    }

}


