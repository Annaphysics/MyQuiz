package com.anna.myquiz;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Process;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

/** This class manages the activity to request and record the data of the examinee at student_info Table of Quiz.db file */
public class LoginAct extends AppCompatActivity  {

    private Button ButSubmit;
    private EditText ETPersonAM;
    private EditText ETPersonName;
    private EditText ETSemester;
    private DataDbHelper StudentDb;


    @Override
    protected void onCreate (Bundle savedInstanceState)
    {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_login);

        ETPersonAM = findViewById (R.id.ETPersonAM);
        ETPersonName = findViewById (R.id.ETPersonName);
        ETSemester = findViewById (R.id.ETSemester);
        ButSubmit = findViewById (R.id.ButSubmit);
        StudentDb = new DataDbHelper (LoginAct.this);

        ButSubmit.setOnClickListener (new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                /** below line is to get data from all edit text fields.*/
                String studentAm = ETPersonAM.getText ().toString ();
                String studentName = ETPersonName.getText ().toString ();
                String studentSemester = ETSemester.getText ().toString ();


                 /**  validating if the text fields are empty or not.*/


                 if (studentAm.isEmpty () || studentName.isEmpty () || studentSemester.isEmpty ())
                     {
                       Toast.makeText (LoginAct.this, "Please enter all the data..", Toast.LENGTH_SHORT).show ();
                       return;
                     }

                /** validating if a student already exists */
                 if (StudentDb.columnExists(studentAm) == true) {

                    Toast.makeText (LoginAct.this, " You have already play...cheater..Goodbye!!!", Toast.LENGTH_LONG).show ();
                    playSound();
                    finishQuiz();
                }
                else {
                    /** on below line we are calling a method to add new
                     * student to sqlite data and pass all our values to it.*/

                    int StudentScore = 0;
                    String studentDate = "";
                    long elapsedTime = 0;
                     StudentDb.addNewStudent (studentAm, studentName, studentSemester, StudentScore, studentDate,elapsedTime);

                    /**  after adding the data we are displaying a toast message.*/
                    Toast.makeText (LoginAct.this, "Student has been added.", Toast.LENGTH_SHORT).show ();
                    ETPersonAM.setText ("");
                    ETPersonName.setText ("");
                    ETSemester.setText ("");
                    startQuiz ();
                }
            }

            /** This method is called when a button is pressed and jumps to a new activity.*/
            private void startQuiz () {

                Intent intent = new Intent (getApplicationContext (), QuestionsAct.class);
                startActivity (intent);
                finish ();
            }
        });
    }
    /** This method is killing the process if an AM entry already exists.*/
    private void finishQuiz()
    {

        Intent intent = new Intent (getApplicationContext (), IntroAct.class);
        startActivity (intent);
        finish ();


    }
    private void playSound() {

        MediaPlayer music = MediaPlayer.create(LoginAct.this, R.raw.wrong_sir_wrong);
        music.start();
    }
}


