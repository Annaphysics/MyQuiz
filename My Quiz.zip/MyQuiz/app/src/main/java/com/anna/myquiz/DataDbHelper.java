package com.anna.myquiz;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.anna.myquiz.DataContract.*;
import java.util.ArrayList;
import java.util.List;


/** This class links the Quiz database with SQLite.*/
public class DataDbHelper extends SQLiteOpenHelper
{

    /** The String stores the name of the database.*/
    private static final String DATABASE_NAME = "Quiz.db";
    /** The integer stores the version of the database*/
    private static final int DATABASE_VERSION = 1;
    private static SQLiteDatabase db;
    private static volatile DataDbHelper instance = null;

    /** This method creates the database.*/
    public DataDbHelper (Context context) {
        super (context, DATABASE_NAME, null, DATABASE_VERSION);
    }


    /** This method assign details to the columns.
     *  It calls commands and statements from SQLite using Strings.*/

    @Override
    public void onCreate (SQLiteDatabase db)
    {
        /** Creates the table of questions.*/
        this.db = db;
        final String SQL_CREATE_QUESTIONS_TABLE = "CREATE TABLE " +
                QuestionTable.TABLE_NAME + " ( " +
                QuestionTable._ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                QuestionTable.COLUMN_QUESTION + " TEXT," +
                QuestionTable.COLUMN_IMAGE + " TEXT," +
                QuestionTable.COLUMN_ANSWER1 + " TEXT," +
                QuestionTable.COLUMN_ANSWER2 + " TEXT," +
                QuestionTable.COLUMN_ANSWER3 + " TEXT," +
                QuestionTable.COLUMN_ANSWER4 + " TEXT," +
                QuestionTable.COLUMN_ANSWERNUM + " INTEGER " +
                ")";

        db.execSQL(SQL_CREATE_QUESTIONS_TABLE);
        fillQuestionsTable();
        /** Creates the table of students.*/
        final String SQL_CREATE_STUDENT_TABLE = "CREATE TABLE " +
                StudentTable.TABLE_NAME1 + " ( " +
                StudentTable.COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                StudentTable.COLUMN_AM + " TEXT," +
                StudentTable.COLUMN_NAME + " TEXT," +
                StudentTable.COLUMN_SEMESTER + " TEXT," +
                StudentTable.COLUMN_GRADE + " TEXT, " +
                StudentTable.COLUMN_DATE + " TEXT, " +
                StudentTable.COLUMN_ELAPSEDTIME + " TEXT " +
                ")";
        db.execSQL(SQL_CREATE_STUDENT_TABLE);

    }

    /** This method can be used to upgrade the tables with newer information.*/
    @Override
    public void onUpgrade (SQLiteDatabase db, int oldVersion, int newVersion)
    {
        db.execSQL("DROP TABLE IF EXISTS " + QuestionTable.TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + StudentTable.TABLE_NAME1);
        onCreate(db);

    }

    /** This method fill the Question table. */
    private void fillQuestionsTable()
    {
        Question q1 = new Question ("Η συνολική αντίσταση του κλάδου ΑΒ έχει τιμή ίση με 8Ω.Άρα η R3 είναι ίση με:  ","circuit", "6Ω" ,"2Ω", "9Ω" , "3Ω", 1);
        addQuestion (q1);
        Question q2 = new Question ("Στο παραπάνω κύκλωμα οι δύο αντιστάτες είναι συνδεδεμένοι:","parallel", "Σε σειρά" ,"Παράλληλα", "Ακτινικά" , null, 2);
        addQuestion (q2);
        Question q3 = new Question ("Στο παραπάνω κύκλωμα οι δύο αντιστάτες είναι συνδεδεμένοι:","seira", "Παράλληλα" ,"Σε διακλάδωση", "Σε σειρά" , null, 3);
        addQuestion (q3);
        Question q4 = new Question ("Στα άκρα δύο αγωγών Α και Β εφαρμόζεται ίδια τάση . Αν για τις αντιστάσεις έχω RA > RΒ , τα ρεύματα ΙA και ΙΒ είναι: ",null, "ΙA < ΙΒ" ,"ΙA = ΙΒ", "ΙA =2ΙΒ" , null, 1);
        addQuestion (q4);
        Question q5 = new Question ("Ωμικός αντιστάτης, αντίστασης R=10Ω διαρρέεται από ρεύμα έντασης 0,1Α. Η τάση στα άκρα του είναι:",null, "10V" ,"100V", "0,1V" , "1V", 4);
        addQuestion (q5);

    }

    /** This method is used to add new question from our sqlite database.*/
    private void addQuestion(Question question)
    {
        ContentValues cv = new ContentValues();
        cv.put(QuestionTable.COLUMN_QUESTION, question.getQuestion());
        cv.put(QuestionTable.COLUMN_IMAGE, question.getImage());
        cv.put(QuestionTable.COLUMN_ANSWER1, question.getAnswer1());
        cv.put(QuestionTable.COLUMN_ANSWER2, question.getAnswer2());
        cv.put(QuestionTable.COLUMN_ANSWER3, question.getAnswer3());

        cv.put(QuestionTable.COLUMN_ANSWER4, question.getAnswer4());
        cv.put(QuestionTable.COLUMN_ANSWERNUM, question.getAnswerNum());
        db.insert(QuestionTable.TABLE_NAME, null, cv);
    }

    /** This method is used to add new student to our sqlite database.*/
    public void addNewStudent(String studentAm, String studentName, String studentSemester, int studentScore, String studentDate, long elapsedTime)
    {

        /** on below line we are creating a variable for
         // our sqlite database and calling writable method
         // as we are writing data in our database.*/
        SQLiteDatabase db = this.getWritableDatabase();

        /** on below line we are creating a  variable for content values.*/
        ContentValues values = new ContentValues();


        /** on below lines  we are passing all values  along with its key and value pair.*/
        values.put(StudentTable.COLUMN_AM, studentAm);
        values.put(StudentTable.COLUMN_NAME, studentName);
        values.put(StudentTable.COLUMN_SEMESTER, studentSemester);
        values.put(StudentTable.COLUMN_GRADE, studentScore);
        values.put(StudentTable.COLUMN_DATE, studentDate);
        values.put(StudentTable.COLUMN_ELAPSEDTIME, elapsedTime);

        /**after adding all values we are passing  content values to our table.*/
        db.insert(StudentTable.TABLE_NAME1, null, values);

        /** at last we are closing our  database after adding database.*/
        db.close();
    }


    /**  This method is used to read all the students from Student Table.    */
    public List<Student> getAllStudent() {
        List<Student> StudentList = new ArrayList<>();
        db = getReadableDatabase ();
        // Choose Random Questions
        Cursor c = db.rawQuery("SELECT * FROM student_info  ",null );


        if (c.moveToFirst()){
            do {
                Student student = new Student ();
                student.setStudentAm(c.getString(c.getColumnIndexOrThrow(StudentTable.COLUMN_AM)));
                student.setStudentName (c.getString(c.getColumnIndexOrThrow(StudentTable.COLUMN_NAME)));
                student.setStudentSemester (c.getString(c.getColumnIndexOrThrow(StudentTable.COLUMN_SEMESTER)));
                student.setStudentScore (c.getInt (c.getColumnIndexOrThrow(StudentTable.COLUMN_GRADE)));
                student.setStudentDate (c.getString(c.getColumnIndexOrThrow(StudentTable.COLUMN_DATE)));
                student.setElapsedTime (c.getLong (c.getColumnIndexOrThrow(StudentTable.COLUMN_ELAPSEDTIME)));

                StudentList.add (student);
            } while (c.moveToNext());
        }
        c.close ();
        return StudentList;
    }

    public boolean columnExists(String studentAm) {
        db = getReadableDatabase ();
        String am = DataContract.StudentTable.COLUMN_AM;
        String sql = "SELECT EXISTS (SELECT * FROM student_info WHERE "+am+" ='"+studentAm+"' LIMIT 1)";
        Cursor cursor = db.rawQuery(sql, null);
        cursor.moveToFirst();

        // cursor.getInt(0) is 1 if column with value exists
        if (cursor.getInt(0) == 1) {
            cursor.close();
            db.close();
            return true;
        } else {
            cursor.close();
            db.close();
            return false;
        }


    }
    /**  we have created a new method for reading all the Questions  from Question Table.    */
    public ArrayList<Question> getAllQuestions() {
        ArrayList<Question> questionList = new ArrayList<>();
        db = getReadableDatabase ();

        /** Choose limit number of Random Questions */
        Cursor c = db.rawQuery("SELECT * FROM quiz_question ORDER BY RANDOM() LIMIT 3 ",null );


        if (c.moveToFirst()){
            do {
                Question question = new Question();
                question.setQuestion(c.getString(c.getColumnIndexOrThrow(QuestionTable.COLUMN_QUESTION)));
                question.setImage (c.getString(c.getColumnIndexOrThrow(QuestionTable.COLUMN_IMAGE)));
                question.setAnswer1(c.getString(c.getColumnIndexOrThrow(QuestionTable.COLUMN_ANSWER1)));
                question.setAnswer2(c.getString(c.getColumnIndexOrThrow(QuestionTable.COLUMN_ANSWER2)));
                question.setAnswer3(c.getString(c.getColumnIndexOrThrow(QuestionTable.COLUMN_ANSWER3)));

                question.setAnswer4(c.getString(c.getColumnIndexOrThrow(QuestionTable.COLUMN_ANSWER4)));
                question.setAnswerNum (c.getInt(c.getColumnIndexOrThrow(QuestionTable.COLUMN_ANSWERNUM)));
                questionList.add (question);
            } while (c.moveToNext());
        }
        c.close ();
        return questionList;
    }


    /**  we have created a new method for storing  student's score and elapsed time  to  Student Table.    */
    public static void addScore(int studentScore,long elapsedTime) {
        String table = DataContract.StudentTable.TABLE_NAME1;
        String id = DataContract.StudentTable.COLUMN_ID;

        ContentValues cv = new ContentValues();
        cv.put(StudentTable.COLUMN_GRADE, studentScore);
        cv.put(StudentTable.COLUMN_ELAPSEDTIME, elapsedTime);
        db.update(
                table,
                cv,
                id + " = (SELECT MAX(" + id + ") FROM " + table + ")",
                null
        );

        db.close();
    }

    /**  we have created a new method for storing  the Quiz Date  taken to Student Table.    */
    public static void storeDate(String formattedDate) {
        String table = DataContract.StudentTable.TABLE_NAME1;
        String id = DataContract.StudentTable.COLUMN_ID;

        ContentValues cv = new ContentValues();
        cv.put(DataContract.StudentTable.COLUMN_DATE, formattedDate);
        db.update(
                table,
                cv,
                id + " = (SELECT MAX(" + id + ") FROM " + table + ")",
                null
        );
        db.close();
    }


}